﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PoolSample
{
    class Program
    {
        public static ObjectPool pool = new ObjectPool();

        static void Main(string[] args)
        {
            Animal dog = new Animal() { Name = "Fido", ID = 1 };
            Vegetable carrot = new Vegetable { Color = "Orange", Identifier = 1, IsTasty = true };
            Mineral carbon = new Mineral() { UniqueID = 2, IsPoisonousToAnimal = false };

            pool.AddItem<Animal>(dog.ID, dog);
            pool.AddItem<Vegetable>(carrot.Identifier, carrot);
            pool.AddItem<Mineral>(carbon.UniqueID, carbon);

            Console.WriteLine("Dog is in the pool -- this statement is " + pool.ContainsKey<Animal>(dog.ID));
            Console.ReadLine();
        }
    }

    public class Animal
    {
        public Int32 ID { get; set; }
        public String Name { get; set; }
    }

    public class Vegetable
    {
        public Int32 Identifier { get; set; }
        public String Color { get; set; }
        public Boolean IsTasty { get; set; }
    }

    public class Mineral
    {
        public Int32 UniqueID { get; set; }
        public Boolean IsPoisonousToAnimal { get; set; }
    }

    public class ObjectPool
    {
        public ObjectPool()
        {
            m_pool = new Dictionary<Type, Dictionary<Int32, Object>>();
        }

        private Dictionary<Type, Dictionary<Int32, Object>> m_pool;

        public void AddItem<T>(Int32 pID, T value)
        {
            Type myType = typeof(T);

            if (!m_pool.ContainsKey(myType))
            {
                m_pool.Add(myType, new Dictionary<int, object>());
                m_pool[myType].Add(pID, value);
                return;
            }

            if (!m_pool[myType].ContainsKey(pID))
            {
                m_pool[myType].Add(pID, value);
                return;
            }

            m_pool[myType][pID] = value;
        }

        public bool RemoveItem<T>(Int32 pID)
        {
            Type myType = typeof(T);

            if (!m_pool.ContainsKey(myType))
                return false;

            if (!m_pool[myType].ContainsKey(pID))
                return false;

            return m_pool[myType].Remove(pID);
        }

        public bool ContainsKey<T>(Int32 pID)
        {
            Type myType = typeof(T);

            if (!m_pool.ContainsKey(myType))
                return false;

            if (!m_pool[myType].ContainsKey(pID))
                return false;

            return m_pool[myType].ContainsKey(pID);
        }

        public IEnumerable<T> GetItems<T>()
        {
            Type myType = typeof(T);

            if (!m_pool.ContainsKey(myType))
                return new T[0];

            return m_pool[myType].Values as IEnumerable<T>;
        }

        /// <summary>
        /// Gets the item.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="pID">The p ID.</param>
        /// <returns></returns>
        /// <exception cref="KeyNotFoundException"></exception>
        public T GetItem<T>(Int32 pID)
        {
            // will throw KeyNotFoundException if either of the dictionaries 
            // does not hold the required key
            return (T) m_pool[typeof(T)][pID];
        }

    }
}

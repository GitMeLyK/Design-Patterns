// Copyright 2004-2011 Castle Project - http://www.castleproject.org/
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

namespace Castle.ActiveRecord.Framework.Config
{
	using System;

	/// <summary>
	/// New configuration interface for ActiveRecord basic functionality
	/// </summary>
	/// <remarks>
	/// This interface is subject to further modification. If you need to implement
	/// this interface, please inherit from <see cref="DefaultActiveRecordConfiguration"/>.
	/// </remarks>
	public interface IActiveRecordConfiguration
	{
		/// <summary>
		/// The <see cref="IThreadScopeInfo"/> to use in ActiveRecord.
		/// </summary>
		Type ThreadScopeInfoImplementation { get; set; }

		/// <summary>
		/// The <see cref="ISessionFactoryHolder"/> to use in ActiveRecord.
		/// </summary>
		Type SessionfactoryHolderImplementation { get; set; }

		/// <summary>
		/// Determines the default Flush-behaviour of <see cref="ISessionScope"/>.
		/// </summary>
		DefaultFlushType DefaultFlushType { get; set; }

		/// <summary>
		/// Determines whether ActiveRecord is configured for use in web apps.
		/// </summary>
		bool WebEnabled { get; set; }

		/// <summary>
		/// Determines whether collections should be loaded lazily by default.
		/// </summary>
		bool Lazy { get; set; }

		/// <summary>
		/// Determines whether the models should be verified against the chosem data stores
		/// at initialization.
		/// </summary>
		bool Verification { get; set; }

		/// <summary>
		/// Determines whether event listeners for NHibernate.Search should be registered.
		/// </summary>
		bool Searchable { get; set; }
	}
}
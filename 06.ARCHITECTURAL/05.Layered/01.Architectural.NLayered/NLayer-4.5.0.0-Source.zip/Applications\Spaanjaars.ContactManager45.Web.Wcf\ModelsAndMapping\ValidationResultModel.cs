using System.Collections.Generic;

namespace Spaanjaars.ContactManager45.Web.Wcf
{
  public class ValidationResultModel
  {
    public string ErrorMessage { get; set; }
    public string[] MemberNames { get; set; }
  }
}

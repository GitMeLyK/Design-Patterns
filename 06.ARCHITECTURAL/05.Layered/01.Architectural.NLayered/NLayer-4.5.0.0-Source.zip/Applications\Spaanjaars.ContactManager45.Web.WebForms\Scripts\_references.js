﻿/// <reference path="jquery-2.0.2.js" />
/// <reference path="jquery.validate.js" />
/// <reference path="modernizr-2.0.6-development-only.js" />

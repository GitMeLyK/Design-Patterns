﻿global using CleanArchitecture.WebUI.AcceptanceTests.Pages;
global using BoDi;
global using FluentAssertions;
global using Microsoft.Playwright;
global using TechTalk.SpecFlow;
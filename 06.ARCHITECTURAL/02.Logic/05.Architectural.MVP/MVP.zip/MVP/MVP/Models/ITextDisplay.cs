﻿namespace MVP.Models
{
    public interface ITextDisplay
    {
        string Reverse(string text);
    }
}

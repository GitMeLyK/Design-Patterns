﻿using MVP.Models;
using MVP.Views;
using System.Windows.Forms;

namespace MVP.Presenter
{
    public  class TextPresenter
    {
        private readonly IView _textDisplay;
        public TextPresenter(IView textDisplay)
        {
            _textDisplay = textDisplay;
            textDisplay.SetText += (o, e) => {
                MessageBox.Show("Text label set to: " + e.ToString());
            };

            textDisplay.ReverseText += (o, e) => {
                MessageBox.Show("Text label reversed from " + e.ToString() + " to: " + _textDisplay.LabelText);
            };

            textDisplay.ClearText += (o, e) => {
                MessageBox.Show("Text label cleared");
            };
        }

        public void ReverseTextDisplay()
        {
            TextDisplay textDisplay = new();
            string currentText = _textDisplay.LabelText;
            var reverseText = textDisplay.Reverse(currentText);
            _textDisplay.LabelText = reverseText;
        }

        public void SetTextDisplay(string text)
        {
            _textDisplay.LabelText = text;
        }

        internal void ClearTextDisplay()
        {
            _textDisplay.LabelText = "";
            _textDisplay.InputText = "";
        }
    }
}

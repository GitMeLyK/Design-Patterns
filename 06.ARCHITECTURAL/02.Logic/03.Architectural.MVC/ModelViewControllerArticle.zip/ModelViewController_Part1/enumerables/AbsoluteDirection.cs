public enum AbsoluteDirection
{
	North=0, East, South, West
}
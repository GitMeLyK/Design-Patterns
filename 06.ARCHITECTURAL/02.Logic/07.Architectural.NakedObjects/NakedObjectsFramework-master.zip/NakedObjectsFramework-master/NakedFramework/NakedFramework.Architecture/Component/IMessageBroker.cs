// Copyright Naked Objects Group Ltd, 45 Station Road, Henley on Thames, UK, RG9 1AT
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the License.
// You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0.
// Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and limitations under the License.

namespace NakedFramework.Architecture.Component;

/// <summary>
///     Service that provides mechanism for passing on various types of messages to the user,
///     in a UI-independent form.
/// </summary>
public interface IMessageBroker {
    string[] PeekMessages { get; }
    string[] PeekWarnings { get; }
    string[] Messages { get; }
    string[] Warnings { get; }
    void AddWarning(string message);
    void AddMessage(string message);
    void ClearWarnings();
    void ClearMessages();
    void EnsureEmpty();
}

// Copyright (c) Naked Objects Group Ltd.
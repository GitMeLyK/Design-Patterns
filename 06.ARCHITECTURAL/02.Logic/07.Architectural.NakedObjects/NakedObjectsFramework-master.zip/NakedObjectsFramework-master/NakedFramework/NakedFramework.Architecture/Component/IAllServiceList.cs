﻿using System;

namespace NakedFramework.Architecture.Component;

public interface IAllServiceList {
    Type[] Services { get; }
}
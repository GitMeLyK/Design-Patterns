# @nakedobjects/restful-objects

A library to help with using the Restful Objects API to a Naked Objects Server

## Further help

Restful Objects
(http://www.restfulobjects.org)

The Naked Objects Framework
(https://github.com/NakedObjectsGroup/NakedObjectsFramework/blob/master/README.md).

import { Injectable } from '@angular/core';

@Injectable()
export class ObfuscateService  {
    public obfuscate(s: string) {
        return s;
    }

    public deobfuscate(s: string) {
        return s;
    }
}

# @nakedobjects/gemini

An implementation of a graphical interface for Naked Objects.

## Further help

The Naked Objects Framework
(https://github.com/NakedObjectsGroup/NakedObjectsFramework/blob/master/README.md).
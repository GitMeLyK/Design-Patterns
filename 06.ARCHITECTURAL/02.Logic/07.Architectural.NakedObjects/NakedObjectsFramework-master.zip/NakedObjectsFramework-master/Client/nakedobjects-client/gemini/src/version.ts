// updated by build do not update manually or change name or regex may not match
export const clientVersion = '12.0.0';

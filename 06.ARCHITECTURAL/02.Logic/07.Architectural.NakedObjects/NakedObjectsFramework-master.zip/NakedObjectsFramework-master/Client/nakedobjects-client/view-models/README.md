# @nakedobjects/view-models

A set of Angular services built on top of the restful-objects API and @nakedobjects/services

## Further help

Restful Objects
(http://www.restfulobjects.org)

The Naked Objects Framework
(https://github.com/NakedObjectsGroup/NakedObjectsFramework/blob/master/README.md).
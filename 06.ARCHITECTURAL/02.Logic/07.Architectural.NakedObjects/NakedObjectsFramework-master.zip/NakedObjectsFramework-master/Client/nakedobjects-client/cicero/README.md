# @nakedobjects/cicero

An implementation of a command line interface for Naked Objects.

## Further help

The Naked Objects Framework
(https://github.com/NakedObjectsGroup/NakedObjectsFramework/blob/master/README.md).

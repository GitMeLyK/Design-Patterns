# @nakedobjects/schematics

Simple schematic to create a new NakedObjects Angular application

## To run 

Create a new project with @angular/cli then scaffold project with schematics

ng new <project>
cd <project>
npm i @nakedobjects/schematics --save-dev
npm i @nakedobjects/gemini
npm i @nakedobjects/cicero
ng serve



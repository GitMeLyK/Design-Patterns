﻿using NOF2.Title;

namespace NOF2.Rest.Test.Data.AppLib;

public interface ITitledObject {
    public ITitle Title();
}
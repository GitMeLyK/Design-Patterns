<?php
namespace Pmjones\Adr\DataSource\Blog;

use ArrayObject;

class BlogRecordSet extends ArrayObject
{
}

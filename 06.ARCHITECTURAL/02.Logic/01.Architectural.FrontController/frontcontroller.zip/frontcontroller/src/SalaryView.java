
public class SalaryView
{
		public void show()
		{
				System.out.println("Displaying Salary Page");
		}
}

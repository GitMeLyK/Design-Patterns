public class UserView
{
		public void show()
		{
				System.out.println("Displaying User Page");
		}
}

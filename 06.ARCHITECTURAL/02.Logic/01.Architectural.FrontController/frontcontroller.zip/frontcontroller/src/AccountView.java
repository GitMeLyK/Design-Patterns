public class AccountView
{
		public void show()
		{
				System.out.println("Displaying Account Page");
		}
}

﻿namespace Spaanjaars.ContactManager45.Model
{
  internal class Constants
  {
    internal const int MaxAgePerson = 130; 
  }
}

﻿using System.Web.Mvc;

namespace Spaanjaars.ContactManager45.Web.Mvc.Controllers
{
  public class HomeController : BaseController
  {
    public ActionResult Index()
    {
      return View();
    }

    public ActionResult About()
    {
      return View();
    }

    public ActionResult Contact()
    {
      return View();
    }
  }
}

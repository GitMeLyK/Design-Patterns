using System.Web.Mvc;

namespace Spaanjaars.ContactManager45.Web.Mvc.Controllers
{
  public class BaseController : Controller
  {
  }
}

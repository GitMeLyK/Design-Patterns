﻿using System.Diagnostics.CodeAnalysis;

namespace Spaanjaars.ContactManager45.Tests.Unit
{
  [ExcludeFromCodeCoverage]
  public class UnitTestBase
  {
  }
}

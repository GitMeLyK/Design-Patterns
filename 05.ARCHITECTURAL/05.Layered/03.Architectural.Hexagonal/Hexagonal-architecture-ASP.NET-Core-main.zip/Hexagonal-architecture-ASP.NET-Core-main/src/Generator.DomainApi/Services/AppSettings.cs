﻿namespace Generator.DomainApi.Services
{
    public class AppSettings
    {
        public ApplicationDetail ApplicationDetail { get; set; }
    }
}

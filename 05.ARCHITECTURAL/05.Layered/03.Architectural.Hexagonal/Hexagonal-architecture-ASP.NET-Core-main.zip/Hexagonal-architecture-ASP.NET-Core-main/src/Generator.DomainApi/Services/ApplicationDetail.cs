﻿namespace Generator.DomainApi.Services
{
    public class ApplicationDetail
    {
        public string ApplicationName { get; set; }
        public string Description { get; set; }
        public string ContactWebsite { get; set; }
        public string LicenseDetail { get; set; }
    }
}

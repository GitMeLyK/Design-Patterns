﻿using System.Collections.Generic;

namespace Generator.DomainApi.Model
{
    public class DealInfo
    {
        public List<Deal> Deals { get; set; }
    }
}

﻿using N_Tier.Core.Entities;

namespace N_Tier.DataAccess.Repositories;

public interface ITodoListRepository : IBaseRepository<TodoList> { }

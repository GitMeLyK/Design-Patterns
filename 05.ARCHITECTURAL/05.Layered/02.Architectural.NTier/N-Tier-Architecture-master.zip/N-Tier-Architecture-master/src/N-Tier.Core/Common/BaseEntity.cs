﻿namespace N_Tier.Core.Common
{
    public abstract class BaseEntity
    {
        public Guid Id { get; set; }
    }
}

﻿namespace N_Tier.Core.Enums
{
    // It is not used in the project, only example
    public enum ExampleTypes
    {
        ExampleOne,
        ExampleTwo
    }
}

﻿using Microsoft.AspNetCore.Mvc;

namespace N_Tier.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ApiController : ControllerBase { }

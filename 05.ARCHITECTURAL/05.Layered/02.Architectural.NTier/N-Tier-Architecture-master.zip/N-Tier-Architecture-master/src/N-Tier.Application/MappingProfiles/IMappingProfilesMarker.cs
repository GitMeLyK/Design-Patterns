﻿namespace N_Tier.Application.MappingProfiles;

// This marker is used for assembly scanning
public interface IMappingProfilesMarker { }

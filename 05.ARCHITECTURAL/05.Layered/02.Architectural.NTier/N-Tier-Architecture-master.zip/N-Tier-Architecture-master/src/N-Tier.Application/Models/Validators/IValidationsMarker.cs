﻿namespace N_Tier.Application.Models.Validators;

// This marker is used for assembly scanning
public interface IValidationsMarker { }

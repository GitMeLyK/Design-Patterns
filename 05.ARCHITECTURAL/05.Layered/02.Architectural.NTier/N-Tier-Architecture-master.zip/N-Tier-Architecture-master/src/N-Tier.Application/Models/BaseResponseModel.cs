﻿namespace N_Tier.Application.Models;

public class BaseResponseModel
{
    public Guid Id { get; set; }
}
